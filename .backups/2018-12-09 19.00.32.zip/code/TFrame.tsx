import * as React from 'react'
import { PropertyControls, ControlType, Frame } from 'framer'
import styled, { css } from 'styled-components'

const StyledFrame = styled(Frame)`
  background: rgba(244, 164, 96, 0.2) !important;
  ${props =>
    props.transition &&
    css`
      transition: ${props.transition};
    `}
`

// Define type of property
interface Props {}

export class TFrame extends React.Component<Props> {
  // Set default properties
  static defaultProps = {
    children: null,
  }

  // Items shown in property panel
  static propertyControls: PropertyControls = {
    transition: { type: ControlType.String, title: 'transition' },
  }

  render() {
    return (
      <StyledFrame transition={this.props.transition}>
        {this.props.children}
      </StyledFrame>
    )
  }
}
