import { Animatable } from 'framer'
const wrapTop = Animatable(231)

const wrapLeft = Animatable(123)
const wrapOpacity = Animatable(1)

const noseScale = Animatable(1)
const noseTop = Animatable(0)
const noseRadius = Animatable('100px')
const noseWidth = Animatable(130)
const noseHeight = Animatable(125)
const noseBoxShadow = [
  {
    inset: false,
    color: 'rgba(0, 0, 0, 0.25)',
    x: 0,
    y: 0,
    blur: 0,
    spread: 0,
  },
]
const noseBackground = Animatable('#DD3137')

export default {
  wrapTop,
  wrapLeft,
  wrapOpacity,
  noseScale,
  noseTop,
  noseRadius,
  noseWidth,
  noseHeight,
  noseBoxShadow,
  noseBackground,
}
