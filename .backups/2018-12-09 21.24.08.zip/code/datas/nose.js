import { Animatable } from 'framer'
export const noseWrapTop = Animatable(231)

export const noseWrapLeft = Animatable(123)
export const noseWrapOpacity = Animatable(1)

export const noseScale = Animatable(1)
export const noseTop = Animatable(0)
export const noseRadius = Animatable('100px')
export const noseWidth = Animatable(130)
export const noseHeight = Animatable(125)
export const noseBoxShadow = [
  {
    inset: false,
    color: 'rgba(0, 0, 0, 0.25)',
    x: 0,
    y: 0,
    blur: 0,
    spread: 0,
  },
]
export const noseBackground = Animatable('#DD3137')
