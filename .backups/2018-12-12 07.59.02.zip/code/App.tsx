import { Data, animate, Override, Animatable } from 'framer'
import { nose1, nose2, nose3, thanks, pages } from './datas'
import { showNose1, showNose2, showNose3, showSnow } from './animate'

export const Pages: Override = () => {
  console.log('pages', pages)
  return {
    onChangePage(event) {
      console.log('event', event)

      animate.ease(eval('nose' + (event + 1)).wrapOpacity, 0.3, { duration: 2 })

      // pages.forEach(page => {
      //   animate.ease(page, 0, { duration: 2 })
      // })

      // data.video = ["Off", "Off", "Off", "Off", "Off"]
      // data.video[event] = "On"
    },
  }
}

// nose
export const NoseWrap01: Override = () => {
  return {
    top: nose1.wrapTop,
    left: nose1.wrapLeft,
    opacity: nose1.wrapOpacity,
  }
}

export const NoseImg: Override = () => {
  return {
    opacity: nose1.noseImgOpacity,
  }
}

export const Nose01: Override = () => {
  return {
    scale: nose1.scale,
    top: nose1.top,
    radius: nose1.radius,
    width: nose1.width,
    height: nose1.height,
    shadows: nose1.shadow,
    blur: nose1.blur,
    background: nose1.background,
    style: {
      transition: 'border-radius 1.2s ease-in-out, box-shadow 1s ease-out',
    },
    onTap: showNose1,
  }
}

export const CoverImage01: Override = () => {
  return {
    // top: nose1.coverImgTop,
    opacity: nose1.coverImgOpacity,
  }
}

export const TitleOverlay01: Override = () => {
  return {
    top: nose1.titleOverlayTop,
  }
}
export const Title01: Override = () => {
  return {
    opacity: nose1.textsTitleOpacity,
    left: nose1.textsTitleLeft,
    scale: nose1.textsTitleScale,
  }
}

export const Author01: Override = () => {
  return {
    opacity: nose1.textsOpacity,
    left: nose1.textsLeft,
  }
}
