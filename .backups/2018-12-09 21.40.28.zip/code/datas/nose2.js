// nose2
const nose2Opacity = Animatable(0.2)
const nose2Scale = Animatable(1)
const nose2Top = Animatable(0)
const nose2Left = Animatable(-111)
const nose2Radius = Animatable('100px')
const nose2Width = Animatable(130)
const nose2Height = Animatable(125)
const nose2BoxShadow = [
  {
    inset: false,
    color: 'rgba(0, 0, 0, 0.25)',
    x: 0,
    y: 0,
    blur: 0,
    spread: 0,
  },
]
const nose2Background = Animatable('#DD3137')

const texts2TitleOpacity = Animatable(0)
const texts2TitleLeft = Animatable(0)
const texts2TitleScale = Animatable(1)

const texts2Opacity = Animatable(0)
const texts2Left = Animatable(0)

const nextBtn2Scale = Animatable(1)
const nextBtn2Opacity = Animatable(0)

export default {
  nose2Opacity,
  nose2Scale,
  nose2Top,
  nose2Left,
  nose2Radius,
  nose2Width,
  nose2Height,
  nose2BoxShadow,
  nose2Background,
  texts2TitleOpacity,
  texts2TitleLeft,
  texts2TitleScale,
  texts2Opacity,
  texts2Left,
  nextBtn2Scale,
  nextBtn2Opacity,
}
