import showNose1 from './showNose1'

export { showNose1 }
