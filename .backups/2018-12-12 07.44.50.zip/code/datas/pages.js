import { Animatable } from 'framer'

const pages = [
  Animatable(0),
  Animatable(1),
  Animatable(1),
  Animatable(1),
  Animatable(1),
]

export default { pages }
