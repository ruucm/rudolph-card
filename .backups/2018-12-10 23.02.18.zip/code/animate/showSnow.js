import { animate } from 'framer'

import { nose, nose2, nose3 } from '../datas'
import { sleep } from '../utils'

const showSnow = async () => {
  nose3.nextBtnScale.set(0.6)
  animate.spring(nose3.nextBtnScale, 2)
}

export default showSnow
