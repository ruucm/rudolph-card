import { animate } from 'framer'

import { nose, nose2, nose3 } from '../datas'
import { sleep } from '../utils'

const showSnow = async () => {
  nose.nextBtnScale.set(0.6)
  animate.ease(nose.nextBtnScale, 60)
  animate.ease(nose.nextBtnBackground, '#004ED8')
}

export default showSnow
