import { animate } from 'framer'

import { nose1 } from '../datas'
import { sleep } from '../utils'

var lock01 = false

const pageHandle = eventIndex => {
  animate.ease(noses[eventIndex].wrapOpacity, 0.3, { duration: 2 })
}

export default pageHandle
