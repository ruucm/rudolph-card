import { animate } from 'framer'

import { nose } from '../datas'
import { sleep } from '../utils'

var lock01 = false

const showNose1 = async () => {
  // nose shirink
  if (!lock01) {
    nose.scale.set(0.6)
    animate.spring(nose.scale, 1)
    lock01 = true
  }

  await sleep(100)

  // animate nose
  animate.easeOut(nose.shadow, [
    {
      inset: false,
      color: 'rgba(0, 0, 0, 0.25)',
      x: 5,
      y: 30,
      blur: 20,
      spread: 0,
    },
  ])
  animate.easeOut(nose.noseImgOpacity, 0)

  await sleep(1000)
  animate.easeOut(nose.top, -104)

  await sleep(700)

  nose.radius.set('20px')

  // animate.easeInOut(nose.radius, '20px')

  await sleep(700)

  animate.easeInOut(nose.width, 300)
  animate.easeInOut(nose.height, 350)
  animate.easeOut(nose.shadow, [
    {
      inset: false,
      color: 'rgba(0, 0, 0, 0.25)',
      x: -15,
      y: 4,
      blur: 20,
      spread: 0,
    },
  ])
  animate.easeInOut(nose.background, 'white')

  await sleep(300)

  // animate coverImg
  animate.easeOut(nose.coverImgOpacity, 0.99, { duration: 0.3 })

  // animate title
  await sleep(800)
  animate.ease(nose.titleOverlayTop, -54, { duration: 0.6 })
}

export default showNose1
