import { Data, animate, Override, Animatable } from 'framer'
import { nose, nose2, nose3, thanks, pages } from './datas'
import { showNose1, showNose2, showNose3, showSnow } from './animate'

export const Pages: Override = () => {
  console.log('pages', pages)
  return {
    onChangePage(event) {
      pages.forEach(page => {
        animate.ease(page, 1, { duration: 1 })
      })
      animate.ease(pages[event], 0, { duration: 1 })

      // data.video = ["Off", "Off", "Off", "Off", "Off"]
      // data.video[event] = "On"
    },
  }
}

// nose
export const NoseWrap01: Override = () => {
  return {
    top: nose.wrapTop,
    left: nose.wrapLeft,
    opacity: nose.wrapOpacity,
  }
}

export const NoseImg: Override = () => {
  return {
    opacity: nose.noseImgOpacity,
  }
}

export const Nose01: Override = () => {
  return {
    scale: nose.scale,
    top: nose.top,
    radius: nose.radius,
    width: nose.width,
    height: nose.height,
    shadows: nose.shadow,
    blur: nose.blur,
    background: nose.background,
    style: {
      transition: 'border-radius 1.2s ease-in-out, box-shadow 1s ease-out',
    },
    onTap: showNose1,
  }
}

export const CoverImage01: Override = () => {
  return {
    // top: nose.coverImgTop,
    opacity: nose.coverImgOpacity,
  }
}

export const TitleOverlay01: Override = () => {
  return {
    top: nose.titleOverlayTop,
  }
}
export const Title01: Override = () => {
  return {
    opacity: nose.textsTitleOpacity,
    left: nose.textsTitleLeft,
    scale: nose.textsTitleScale,
  }
}

export const Author01: Override = () => {
  return {
    opacity: nose.textsOpacity,
    left: nose.textsLeft,
  }
}
