import { showNose1, showNose2, showNose3 } from '../animate'

const animations = [showNose1, showNose2, showNose3]
const animationsLock = [false, false, false]

const pageHandle = eventIndex => {
  console.log('eventIndex', eventIndex)
  if (!animationsLock[eventIndex]) {
    animations[eventIndex]()
    eventIndex = true
  }
}

export default pageHandle
