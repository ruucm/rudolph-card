import nose1 from './nose1'
import nose2 from './nose2'
import nose3 from './nose3'
import thanks from './thanks'

export { nose1, nose2, nose3, thanks }
