const snowOn = false

export default {
  snowOn,
}
