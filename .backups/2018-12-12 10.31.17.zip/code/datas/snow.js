import { Data } from 'framer'

const data = Data({
  snowOn = false
})

export default data




