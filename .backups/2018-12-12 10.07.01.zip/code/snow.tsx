import * as React from 'react'
import { PropertyControls, ControlType } from 'framer'
import styled from 'styled-components'

const Wrap = styled.div`

/* html {
  height: 100%;
}
body {
  width: 100%;
  height: 100%;
  background: hsl(190,70%,30%); 
  background: -moz-linear-gradient(top, hsl(190,70%,30%) 0%, hsl(190,70%,60%) 100%); /* FF3.6+ */
  background: -webkit-linear-gradient(top, #f0f9ff 0%, hsl(190,70%,60%) 100%); /* Chrome10+,Safari5.1+ */
  background: -o-linear-gradient(top, hsl(190,70%,30%) 0%, hsl(190,70%,60%) 100%); /* Opera 11.10+ */
  background: -ms-linear-gradient(top, hsl(190,70%,30%) 0%, hsl(190,70%,60%) 100%); /* IE10+ */
  background: linear-gradient(to bottom, hsl(190,70%,30%) 0%, hsl(190,70%,60%) 100%);
} */
.svg-snowscene {
  width: 100%;
}
.snow {
  fill: blue; 
  animation-name: snowing;
  animation-duration: 3s;
  animation-iteration-count: infinite;
  animation-timing-function: ease-out;
  &:nth-child(2n){
    animation-delay: 1.5s;
  }
  &:nth-child(3n){
    animation-delay: 2.3s;
    animation-duration: 3.3s;
  }
  &:nth-child(4n){
    animation-delay: 0.8s;
    animation-duration: 3.2s;
  }
  &:nth-child(5n){
    animation-delay: 2.8s;
  }
}

@keyframes snowing {
  0%{ fill-opacity: 1; }
  100% { 
    fill-opacity: 0;
    transform: translateY(200px);
  }
}

`

// Define type of property
interface Props {
  text: string
}

export class snow extends React.Component<Props> {
  // Set default properties
  static defaultProps = {
    text: 'Hello World!',
  }

  // Items shown in property panel
  static propertyControls: PropertyControls = {
    text: { type: ControlType.String, title: 'Text' },
  }

  render() {
    return (
      <Wrap>
        <svg className="svg-snowscene" xmlns="http://www.w3.org/2000/svg">
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
          <circle className="snow" />
        </svg>
      </Wrap>
    )
  }
}
