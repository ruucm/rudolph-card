import { animate } from 'framer'
import { showNose1, showNose2, showNose3 } from '../animate'

import { nose1, nose2, nose3 } from '../datas'
import { animate } from 'framer'

const noses = [nose1, nose2, nose3]
const animations = [showNose1, showNose2, showNose3]
const lock = [false, false, false]

const fadeOthers = index => {
  for (let i = 0; index < noses.i; i++) {
    if (i != index) animate.easeInOut(noses[i].wrapOpacity, 0.3)
  }
}

const pageHandle = index => {
  if (!lock[index]) {
    console.log('animate! - ', index)
    animations[index]()
    fadeOthers(index)
    lock[index] = true
  }
}

export default pageHandle
