import { animate } from 'framer'

import { nose1, nose2, nose3, thanks, pages } from './datas'

import { sleep } from '../utils'

var lock01 = false

const noses = [nose1, nose2, nose3]

const pageHandle = eventIndex => {
  animate.ease(noses[eventIndex].wrapOpacity, 0.3, { duration: 2 })
}

export default pageHandle
