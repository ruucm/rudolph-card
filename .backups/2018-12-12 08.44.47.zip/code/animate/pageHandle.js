import { showNose1, showNose2, showNose3 } from '../animate'

const animations = [showNose1, showNose2, showNose3]
const lock = [false, false, false]

const pageHandle = eventIndex => {
  if (!lock[eventIndex]) {
    console.log('animate! - ', eventIndex)
    animations[eventIndex]()
    lock[eventIndex] = true
  }
}

export default pageHandle
