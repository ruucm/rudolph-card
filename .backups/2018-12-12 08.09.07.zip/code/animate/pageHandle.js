import { animate } from 'framer'

import { nose1, nose2, nose3, thanks, pages } from './datas'

const noses = [nose1, nose2, nose3]

const pageHandle = eventIndex => {
  console.log('eventIndex', eventIndex)
  animate.ease(noses[eventIndex].wrapOpacity, 0.3, { duration: 2 })
}

export default pageHandle
