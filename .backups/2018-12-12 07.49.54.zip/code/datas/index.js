import nose from './nose'
import nose2 from './nose2'
import nose3 from './nose3'
import thanks from './thanks'
import pages from './pages'

export { nose, nose2, nose3, thanks, pages }
