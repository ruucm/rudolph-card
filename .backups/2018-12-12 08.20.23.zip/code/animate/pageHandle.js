import { animate } from 'framer'
import { nose1, nose2, nose3, thanks, pages } from '../datas'

import { showNose1, showNose2, showNose3 } from '../animate'

// import showNose2 from './showNose2'

const noses = [nose1, nose2, nose3]

const animations = [showNose1, showNose2, showNose3]

const pageHandle = eventIndex => {
  console.log('eventIndex', eventIndex)
  // animate.ease(noses[eventIndex].wrapOpacity, 0.3, { duration: 2 })

  // if (eventIndex == 1) showNose2()

  animations[eventIndex]()
}

export default pageHandle
