import showNose1 from './showNose1'
import showNose2 from './showNose2'
import showNose3 from './showNose3'

export { showNose1, showNose2, showNose3 }
